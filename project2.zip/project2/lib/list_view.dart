import 'package:flutter/material.dart';

class ListViewScreen extends StatelessWidget {
  final List<String> names = [
    "Sarip Raja Iblis",
    "Mahes Anti Koplo",
    "Faizal Permana",
    "Nuansa Ilham",
    "Rapli Pangeran Iblis",
    "Adi Winclick",
    "Haffiant Russle",
    "Memet Yanto",
    "Memet Amir",
    "Garin MANTAPANCING",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Daftar Mahasiswa TI 23A2"),
        backgroundColor: Colors.blueAccent,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(10),
        itemCount: names.length,
        itemBuilder: (context, index) {
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blueAccent,
                child: Text(
                  names[index][0], // Inisial dari nama
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(
                names[index],
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              subtitle: Text("Tap to view details"),
              trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey),
              onTap: () {
                // Tambahkan aksi saat list ditekan
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("You tapped on ${names[index]}")),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
